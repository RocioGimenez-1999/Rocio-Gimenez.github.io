function descargarCV() {
    window.print();  // Esta función abre el diálogo para imprimir o guardar como PDF
}