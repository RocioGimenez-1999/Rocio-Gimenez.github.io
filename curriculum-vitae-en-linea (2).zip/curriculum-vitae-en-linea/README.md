# curriculum vitae en Linea 

A Pen created on CodePen.io. Original URL: [https://codepen.io/ROCIO-GIMENEZ/pen/dyxNBdQ](https://codepen.io/ROCIO-GIMENEZ/pen/dyxNBdQ).

